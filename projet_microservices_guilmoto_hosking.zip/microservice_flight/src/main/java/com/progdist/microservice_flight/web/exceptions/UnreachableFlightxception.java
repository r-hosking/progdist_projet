package com.progdist.microservice_flight.web.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class UnreachableFlightxception extends RuntimeException {
	
	public UnreachableFlightxception(String s) {
		super(s);
	}
}
