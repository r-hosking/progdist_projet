package com.progdist.microservice_flight.web.controller;

import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.progdist.microservice_flight.model.Flight;
import com.progdist.microservice_flight.web.dao.FlightDao;
import com.progdist.microservice_flight.web.exceptions.UnreachableFlightxception;

import java.net.URI;

@RestController
public class FlightController {
	
	@Autowired
	private FlightDao flightDao;

	  //Récupérer la liste des produits
	  @RequestMapping(value = "/Flights", method = RequestMethod.GET)
	  
	  public MappingJacksonValue listFlights() {
		  Iterable<Flight> flights = flightDao.findAll();
		  MappingJacksonValue flightsMjv = new MappingJacksonValue(flights);
	      return flightsMjv;
	  }

	  @GetMapping(value = "/Flights/{id}")
	  public Flight displayFlight(@PathVariable int id){
		  Flight produit = flightDao.findById(id);
	      if(produit==null) throw new UnreachableFlightxception("Le vold n°" + id + " est introuvable.");
	   return produit;
	  }
	  
	  @GetMapping(value = "test/flights/{price}")
	  public List<Flight> testeDeRequetes(@PathVariable int price) 
	  {
	     return flightDao.findByPriceGreaterThan(400);
	  }
	  
	  
	  @PostMapping(value = "/Flights")
	  public ResponseEntity<Void> addProduit(@Valid @RequestBody Flight flight){
		  Flight productAdded = flightDao.save(flight);
	      if (Objects.isNull(productAdded)) {
	          return ResponseEntity.noContent().build();
	      }
	      URI location = ServletUriComponentsBuilder
	              .fromCurrentRequest()
	              .path("/{id}")
	              .buildAndExpand(productAdded.getId())
	              .toUri();
	      return ResponseEntity.created(location).build();
	  }
	  
	  @DeleteMapping(value = "/Flights/{id}")
	  public void deleteFligh(@PathVariable int id) {
		  flightDao.deleteById(id);
	  }
	  
	  @PutMapping(value = "/Flights")
	  public void updateFlight(@RequestBody Flight flight){
		  flightDao.save(flight);
	  }
}
