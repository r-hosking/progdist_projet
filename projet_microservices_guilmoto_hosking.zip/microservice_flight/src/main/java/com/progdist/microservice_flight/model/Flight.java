package com.progdist.microservice_flight.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

@Entity
public class Flight {
	@Id
	private int id;
	@Size(min = 3, max = 255)
	private String name;
	@Min(value = 1)
	private int price;
	private String company;
	public Flight(){
		
	}
	
	public Flight(int id, String name, int price, String company) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.company = company;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public float getPrice() {
		return price;
	}
	
	public void setPrice(int price) {
		this.price = price;
	}
	
	public String getCompany() {
		return company;
	}
	
	public void setCompany(String company) {
		this.company = company;
	}
	
	@Override
	public String toString() {
		return "Flight [id=" + id + ", name=" + name + ", price=" + price + ", company=" + company + "]";
	}

}
