CREATE TABLE flight(
   id INT PRIMARY KEY,
   name VARCHAR(255) NOT NULL,
   price INT NOT NULL,
   company VARCHAR(255) NOT NULL
   );