INSERT INTO flight VALUES(1, 'Paris-Londres', 350, 'Air France');
INSERT INTO flight VALUES(2, 'Paris-Barcelone', 300, 'Air France');
INSERT INTO flight VALUES(3, 'Paris-Madrid', 750, 'Air France');