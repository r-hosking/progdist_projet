http://localhost:9090/Flights/
http://localhost:9090/h2-console/
	JDBC URL -> jdbc:h2:mem:testdb
	
SELECT * FROM FLIGHT

http://localhost:9090/v2/api-docs
http://localhost:9090/swagger-ui/