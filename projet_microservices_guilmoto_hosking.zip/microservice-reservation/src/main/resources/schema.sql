CREATE TABLE reservation(
   id INT PRIMARY KEY,
   name VARCHAR(255) NOT NULL,
   flight_id INT REFERENCES Flight(id)
   );