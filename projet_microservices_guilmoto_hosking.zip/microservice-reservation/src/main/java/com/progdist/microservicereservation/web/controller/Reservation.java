package com.progdist.microservicereservation.web.controller;

public class Reservation {
	private int id;
	private String name;
	private int flightId;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getflightId() {
		return flightId;
	}
	public void setflightId(int id) {
		this.flightId = id;
	}
	
}
